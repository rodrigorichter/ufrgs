#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
using namespace std;

string ptgSucks(string s){
	for (char c : s){
		if (c == 192 || 193 || 194 || 195 || 196 || 197){ c = 'A'; }
		if (c == 199) { c = 'C'; }
		if (c == 200 || 201 || 202 || 203) { c = 'E'; }
		if (c == 204 || 205 || 206 || 207) { c = 'I'; }
		if (c == 210 || 211 || 212 || 213 || 214){ c = 'O'; }
		if (c == 217 || 218 || 219 || 220){ c = 'U'; }
	}
	return s;
}

void catalogNames(){																	// Reads file and creates index file with article names as key and byte displacement as address

	fstream file;																		// Creates file object
	ofstream catalog;																	// Creates output file object
	int semicolon;																		// Counter for number of semicolons read in a line
	int displacement;																	// Stores distance from file start in chars
	string s1;																			// Auxiliary string - stores full line
	string name;																		// Auxiliary string - stores a name to be pushed to the "names" vector
	vector<string> names;																// Vector of strings to store primary key (name of article)

	file.open("Artigos.csv");															// Opens file
	getline(file, s1);																	// Reads but disregards template line
	while (!file.eof()){																// For the entire file:
		name = "";																		// Resets string to empty
		displacement = file.tellg();													// Before reading a line, get its byte displacement via the file marker
		getline(file, s1);																// Copies line to auxiliary string
		semicolon = 0;																	// Resets semicolon counter
		for (char c : s1){																// Searches every character in a line
			if (c == ';' && semicolon < 3){ semicolon++; }								// Until three semicolons have been read...
			else if (semicolon < 3){}													// ... do nothing
			else if (semicolon == 3 && c != ';') { name+= c; }							// Chars between the 3rd and 4th semicolons are added to the "name" string
			else break;																	// Remaining chars are ignored
		}																				// Finished retrieving a name from the line
		if (name == ""){ break; }														// If name is empty, skips adding it and its displacement
		else{																			// If not:
			name.append(" ");															// Appends a whitespace for future searches by word
			name += '\n';														        // Appends a newline to separate name from its line's soon-to-be-appended byte displacement

			{ostringstream convert;														// Creates stream object used to convert int value to its string representation
			convert << displacement;													// Converts displacement
			s1 = convert.str();															// s1 now contains displacement
			}																			// Ends scope to delete ostringstream object

			name.append(s1);															// Appends displacement to name, in the form name;displacement
			names.push_back(name);														// Name pushed to "names" vector
		}																				
	}																					// Repeats for every line
	file.close();																		// Closes file

	sort(names.begin(), names.end());													// Sorts names in n(log n) time

	catalog.open("namesCatalog.bin");													// Creates and opens name catalog file
		for (string s : names){															// Writes every name and its respective displacement
			catalog << s << endl;
		}
	catalog.close();																	// Closes file

}

void catalogAuthors(){

	fstream mainfile;																	// Creates file object for Artigos.csv
	fstream namesfile;																	// Creates file object for namesCatalog.bin
	ofstream catalog;																	// Creates output file object
	int semicolon;																		// Counter for number of semicolons read in a line
	int sc_author;																		// Tracks from which author field a string will be extracted
	int displacement;																	// Stores distance from main file start in chars
	int displacement2;																	// Stores distance from names catalog file start in chars
	string s1;																			// Auxiliary string - stores full line
	string s2;																			// Auxiliary string - stores a char-represented number to be appended to the "author" string
	string author;																		// Auxiliary string - stores a name to be pushed to the "authors" vector
	vector<string> authors;																// Vector of strings to store secondary key (author of the article)

	namesfile.open("namesCatalog.bin");													// Opens names catalog file
	mainfile.open("Artigos.csv");														// Opens main file		
	
	while (!namesfile.eof()){															// For the entire file:
		sc_author = 21;																	// Initializes author field at its first value - after 21 semicolons
		displacement2 = namesfile.tellg();												// Before reading a line, get its byte displacement via the file marker
		getline(namesfile, s1);															// Reads name line but disregards it
		if (s1 == ""){ break; }
		getline(namesfile, s1);															// Reads address line and copies it to auxiliary string

		{istringstream convert(s1);														// Creates stream object used to convert string to int
		convert >> displacement;														// Puts conversion in the displacement variable
		}																				// Ends scope to delete istringstream object

		mainfile.seekg(displacement, mainfile.beg);										// Changes file marker of main file to the value given by the namesCatalog file
		getline(mainfile, s1);															// Reads line from main file

		while (sc_author < 32){															// As long as within the maximum number of fields
			author = "";																// Resets author string
			semicolon = 0;																// Resets semicolon counter
			for (char c : s1){															// Searches every character in a line
				if (c == ';' && semicolon < sc_author){ semicolon++; }					// Until a number of semicolons have been read...
				else if (semicolon < sc_author){}										// ... do nothing
				else if (semicolon == sc_author && c != ';') author += c;				// Chars between the sc_author and sc_author+1 semicolons are added to the "author" string
				else break;																// Remaining chars are ignored
			}
			if (author == ""){ break; }													// If author is empty, skips adding it and its displacement
			author += '\n';																// Appends a newline to separate name from its namesCatalog line's soon-to-be-appended byte displacement2

			{ostringstream convert;														// Creates stream object used to convert int value to its string representation
			convert << displacement2;													// Converts displacement2
			s2 = convert.str();															// s2 now contains displacement2
			}																			// Ends scope to delete ostringstream object

			author.append(s2);															// Appends displacement to name, in the form author;displacement2
			authors.push_back(author);													// Author pushed to "authors" vector
			sc_author += 2;																// Next author field will be extracted on next loop
		}

	}
		sort(authors.begin(), authors.end());											// Sorts authors in n(log n) time -- Because they possess displacement of an alphabetically-sorted-by-name list,
																						// each grouping of entries with the same author name will already be ordered by its article's names

		catalog.open("authorsCatalog1.bin");											// Creates and opens author catalog file
		for (string s : authors){														// Writes every author and its respective displacement
			catalog << s << endl;
		}
		catalog.close();																// Closes files
		namesfile.close();
		mainfile.close();

}

void catalogAuthors2(){

	fstream authorsfile;																// Creates file object for authorsCatalog1.bin
	fstream namesfile;																	// Creates file object for namesCatalog.bin
	ofstream catalog;																	// Creates output file object
	int displacement;																	// Stores distance from names catalog file start in chars
	int displacement2;																	// Stores distance from authors catalog file start in chars
	string s1;																			// Auxiliary string - stores full line
	string author;																		// Auxiliary string - stores a name of author to be written on the final catalog
	string real_address;																// String to hold the "displacement" value before conversion to int 

	authorsfile.open("authorsCatalog1.bin");											// Opens authors catalog file
	namesfile.open("namesCatalog.bin");													// Opens names catalog file	
	catalog.open("authorsCatalog2.bin");

	while (!authorsfile.eof()){															// For the entire file:
		getline(authorsfile, author);													// Stores author name on the author string
		catalog << author << endl;														// Writes it on the final author's catalog
		getline(authorsfile, s1);														// Stores address string on the auxiliary string

		{istringstream convert(s1);														// Creates stream object used to convert string to int
		convert >> displacement;														// Puts conversion in the displacement variable
		}																				// Ends scope to delete istringstream object

		namesfile.seekg(displacement, namesfile.beg);									// Changes file marker to point to the line indicated by displacement
		getline(namesfile, s1);															// Copies said line (the one with an article's title on it) to s1, just to skip this line
		getline(namesfile, s1);															// Copies the following line (the one with the displacement value of the main file) to s1
		catalog << s1 << ";";															// Writes said displacement to the final author's catalog, along with a semicolon for separation
																						// Preparing to search for additional displacements with same author...
		displacement2 = authorsfile.tellg();											// Saves the current position of the file marker in case the next entry has a different author
		getline(authorsfile, s1);														// Copies the next author name to s1
		if (s1 == "") break;															// Quits if there's a blank line to avoid infinite looping if it happens at eof
		while (author == s1){															// If the name of the most recently read entry is the name of the author currently being processed:
			getline(authorsfile, s1);													// Copies displacement of said entry to s1
									
			{istringstream convert(s1);													// Creates stream object used to convert string to int
			convert >> displacement;													// Puts conversion in the displacement2 variable
			}																			// Ends scope to delete istringstream object

			namesfile.seekg(displacement, namesfile.beg);								// Changes file marker to point to the line indicated by displacement
			getline(namesfile, s1);														// Copies said line (the one with an article's title on it) to s1, just to skip this line
			getline(namesfile, s1);														// Copies the following line (the one with the displacement value of the main file) to s1
			catalog << s1 << ";";														// Writes said displacement to the final author's catalog, along with a semicolon for separation
			displacement2 = authorsfile.tellg();										// Saves the current position of the file marker in case the next entry has a different author
			getline(authorsfile, s1);													// Copies the next entry's author name to s1 so it can be compared in the next while loop iteration
		}
		authorsfile.seekg(displacement2, authorsfile.beg);								// Breaking from while loop means a different author has been read. Returns one line of the authors file
		catalog << endl;																// Writes a newline on the final catalog file to start processing a new author
	}

	authorsfile.close();
	namesfile.close();
	catalog.close();

}

void catalogCountries(){
	fstream mainfile;																	// Creates file object for Artigos.csv
	fstream namesfile;																	// Creates file object for namesCatalog.bin
	ofstream catalog;																	// Creates output file object
	int semicolon;																		// Counter for number of semicolons read in a line
	int displacement;																	// Stores distance from main file start in chars
	int displacement2;																	// Stores distance from names catalog file start in chars
	string s1;																			// Auxiliary string - stores full line
	string s2;																			// Auxiliary string - stores a char-represented number to be appended to the "country" string
	string country;																		// Auxiliary string - stores a name to be pushed to the "countries" vector
	vector<string> countries;															// Vector of strings to store secondary key (country of the article)

	namesfile.open("namesCatalog.bin");													// Opens names catalog file
	mainfile.open("Artigos.csv");														// Opens main file		

	while (!namesfile.eof()){															// For the entire file:
		displacement2 = namesfile.tellg();												// Before reading a line, get its byte displacement via the file marker
		getline(namesfile, s1);															// Reads name line but disregards it
		if (s1 == ""){ break; }
		getline(namesfile, s1);															// Reads address line and copies it to auxiliary string

		{istringstream convert(s1);														// Creates stream object used to convert string to int
		convert >> displacement;														// Puts conversion in the displacement variable
		}																				// Ends scope to delete istringstream object

		mainfile.seekg(displacement, mainfile.beg);										// Changes file marker of main file to the value given by the namesCatalog file
		getline(mainfile, s1);															// Reads line from main file

		country = "";																	// Resets country string
		semicolon = 0;																	// Resets semicolon counter
		for (char c : s1){																// Searches every character in a line
			if (c == ';' && semicolon < 8){ semicolon++; }								// Until eight semicolons have been read...
			else if (semicolon < 8){}													// ... do nothing
			else if (semicolon == 8 && c != ';') { country += c; }						// Chars between the 8th and 9th semicolons are added to the "country" string
			else break;																	// Remaining chars are ignored
		}
			if (country == ""){ break; }												// If country is empty, quits process
			country += '\n';															// Appends a newline to separate name from its namesCatalog line's soon-to-be-appended byte displacement2

			{ostringstream convert;														// Creates stream object used to convert int value to its string representation
			convert << displacement2;													// Converts displacement2
			s2 = convert.str();															// s2 now contains displacement2
			}																			// Ends scope to delete ostringstream object

			country.append(s2);															// Appends displacement to name, in the form country;displacement2
			countries.push_back(country);												// Country pushed to "countries" vector

	}
	sort(countries.begin(), countries.end());											// Sorts countries in n(log n) time -- Because they possess displacement of an alphabetically-sorted-by-name list,
																						// each grouping of entries with the same country name will already be ordered by its article's names

	catalog.open("countriesCatalog1.bin");												// Creates and opens country catalog file
	for (string s : countries){															// Writes every country and its respective displacement
		catalog << s << endl;
	}
	catalog.close();																	// Closes files
	namesfile.close();
	mainfile.close();

}

void catalogCountries2(){

	fstream countriesfile;																// Creates file object for countriesCatalog1.bin
	fstream namesfile;																	// Creates file object for namesCatalog.bin
	ofstream catalog;																	// Creates output file object
	int displacement;																	// Stores distance from names catalog file start in chars
	int displacement2;																	// Stores distance from countries catalog file start in chars
	string s1;																			// Auxiliary string - stores full line
	string country;																		// Auxiliary string - stores a name of country to be written on the final catalog
	string real_address;																// String to hold the "displacement" value before conversion to int 

	countriesfile.open("countriesCatalog1.bin");										// Opens countries catalog file
	namesfile.open("namesCatalog.bin");													// Opens names catalog file	
	catalog.open("countriesCatalog2.bin");

	while (!countriesfile.eof()){														// For the entire file:
		getline(countriesfile, country);												// Stores country name on the country string
		catalog << country << endl;														// Writes it on the final country's catalog
		getline(countriesfile, s1);														// Stores address string on the auxiliary string

		{istringstream convert(s1);														// Creates stream object used to convert string to int
		convert >> displacement;														// Puts conversion in the displacement variable
		}																				// Ends scope to delete istringstream object

		namesfile.seekg(displacement, namesfile.beg);									// Changes file marker to point to the line indicated by displacement
		getline(namesfile, s1);															// Copies said line (the one with an article's title on it) to s1, just to skip this line
		getline(namesfile, s1);															// Copies the following line (the one with the displacement value of the main file) to s1
		catalog << s1 << ";";															// Writes said displacement to the final country's catalog, along with a semicolon for separation
																						// Preparing to search for additional displacements with same country...
		displacement2 = countriesfile.tellg();											// Saves the current position of the file marker in case the next entry has a different country
		getline(countriesfile, s1);														// Copies the next country name to s1
		if (s1 == "") break;															// Quits if there's a blank line to avoid infinite looping if it happens at eof
		while (country == s1){															// If the name of the most recently read entry is the name of the country currently being processed:
			getline(countriesfile, s1);													// Copies displacement of said entry to s1

			{istringstream convert(s1);													// Creates stream object used to convert string to int
			convert >> displacement;													// Puts conversion in the displacement2 variable
			}																			// Ends scope to delete istringstream object

			namesfile.seekg(displacement, namesfile.beg);								// Changes file marker to point to the line indicated by displacement
			getline(namesfile, s1);														// Copies said line (the one with an article's title on it) to s1, just to skip this line
			getline(namesfile, s1);														// Copies the following line (the one with the displacement value of the main file) to s1
			catalog << s1 << ";";														// Writes said displacement to the final country's catalog, along with a semicolon for separation
			displacement2 = countriesfile.tellg();										// Saves the current position of the file marker in case the next entry has a different country
			getline(countriesfile, s1);													// Copies the next entry's country name to s1 so it can be compared in the next while loop iteration
		}
		countriesfile.seekg(displacement2, countriesfile.beg);							// Breaking from while loop means a different country has been read. Returns one line of the country file
		catalog << endl;																// Writes a newline on the final catalog file to start processing a new country
	}

	countriesfile.close();
	namesfile.close();
	catalog.close();

}

void catalogFields(){

	fstream mainfile;																	// Creates file object for Artigos.csv
	fstream namesfile;																	// Creates file object for namesCatalog.bin
	ofstream catalog;																	// Creates output file object
	int semicolon;																		// Counter for number of semicolons read in a line
	int displacement;																	// Stores distance from main file start in chars
	int displacement2;																	// Stores distance from names catalog file start in chars
	string s1;																			// Auxiliary string - stores full line
	string s2;																			// Auxiliary string - stores a char-represented number to be appended to the "field" string
	string field;																		// Auxiliary string - stores a name to be pushed to the "fields" vector
	vector<string> fields;																// Vector of strings to store secondary key (field of the article)

	namesfile.open("namesCatalog.bin");													// Opens names catalog file
	mainfile.open("Artigos.csv");														// Opens main file		

	while (!namesfile.eof()){															// For the entire file:
		displacement2 = namesfile.tellg();												// Before reading a line, get its byte displacement via the file marker
		getline(namesfile, s1);															// Reads name line but disregards it
		if (s1 == ""){ break; }
		getline(namesfile, s1);															// Reads address line and copies it to auxiliary string

		{istringstream convert(s1);														// Creates stream object used to convert string to int
		convert >> displacement;														// Puts conversion in the displacement variable
		}																				// Ends scope to delete istringstream object

		mainfile.seekg(displacement, mainfile.beg);										// Changes file marker of main file to the value given by the namesCatalog file
		getline(mainfile, s1);															// Reads line from main file

		field = "";																		// Resets field string
		semicolon = 0;																	// Resets semicolon counter
		for (char c : s1){																// Searches every character in a line
			if (c == ';' && semicolon < 18){ semicolon++; }								// Until eight semicolons have been read...
			else if (semicolon < 18){}													// ... do nothing
			else if (semicolon == 18 && c != ';') { field += c; }						// Chars between the 8th and 9th semicolons are added to the "field" string
			else break;																	// Remaining chars are ignored
		}
		if (field == ""){ break; }														// If field is empty, quits process
		field += '\n';																	// Appends a newline to separate name from its namesCatalog line's soon-to-be-appended byte displacement2

		{ostringstream convert;															// Creates stream object used to convert int value to its string representation
		convert << displacement2;														// Converts displacement2
		s2 = convert.str();																// s2 now contains displacement2
		}																				// Ends scope to delete ostringstream object

		field.append(s2);																// Appends displacement to name, in the form field;displacement2
		fields.push_back(field);														// Country pushed to "fields" vector

	}
	sort(fields.begin(), fields.end());													// Sorts fields in n(log n) time -- Because they possess displacement of an alphabetically-sorted-by-name list,
																						// each grouping of entries with the same field name will already be ordered by its article's names

	catalog.open("fieldsCatalog1.bin");													// Creates and opens field catalog file
	for (string s : fields){															// Writes every field and its respective displacement
		catalog << s << endl;
	}
	catalog.close();																	// Closes files
	namesfile.close();
	mainfile.close();


}

void catalogFields2(){

	fstream fieldsfile;																	// Creates file object for fieldsCatalog1.bin
	fstream namesfile;																	// Creates file object for namesCatalog.bin
	ofstream catalog;																	// Creates output file object
	int displacement;																	// Stores distance from names catalog file start in chars
	int displacement2;																	// Stores distance from fields catalog file start in chars
	string s1;																			// Auxiliary string - stores full line
	string field;																		// Auxiliary string - stores a name of field to be written on the final catalog
	string real_address;																// String to hold the "displacement" value before conversion to int 

	fieldsfile.open("fieldsCatalog1.bin");												// Opens fields catalog file
	namesfile.open("namesCatalog.bin");													// Opens names catalog file	
	catalog.open("fieldsCatalog2.bin");

	while (!fieldsfile.eof()){															// For the entire file:
		getline(fieldsfile, field);														// Stores field name on the field string
		catalog << field << endl;														// Writes it on the final field's catalog
		getline(fieldsfile, s1);														// Stores address string on the auxiliary string

		{istringstream convert(s1);														// Creates stream object used to convert string to int
		convert >> displacement;														// Puts conversion in the displacement variable
		}																				// Ends scope to delete istringstream object

		namesfile.seekg(displacement, namesfile.beg);									// Changes file marker to point to the line indicated by displacement
		getline(namesfile, s1);															// Copies said line (the one with an article's title on it) to s1, just to skip this line
		getline(namesfile, s1);															// Copies the following line (the one with the displacement value of the main file) to s1
		catalog << s1 << ";";															// Writes said displacement to the final field's catalog, along with a semicolon for separation
																						// Preparing to search for additional displacements with same field...
		displacement2 = fieldsfile.tellg();												// Saves the current position of the file marker in case the next entry has a different field
		getline(fieldsfile, s1);														// Copies the next field name to s1
		if (s1 == "") break;															// Quits if there's a blank line to avoid infinite looping if it happens at eof
		while (field == s1){															// If the name of the most recently read entry is the name of the field currently being processed:
			getline(fieldsfile, s1);													// Copies displacement of said entry to s1

			{istringstream convert(s1);													// Creates stream object used to convert string to int
			convert >> displacement;													// Puts conversion in the displacement2 variable
			}																			// Ends scope to delete istringstream object

			namesfile.seekg(displacement, namesfile.beg);								// Changes file marker to point to the line indicated by displacement
			getline(namesfile, s1);														// Copies said line (the one with an article's title on it) to s1, just to skip this line
			getline(namesfile, s1);														// Copies the following line (the one with the displacement value of the main file) to s1
			catalog << s1 << ";";														// Writes said displacement to the final field's catalog, along with a semicolon for separation
			displacement2 = fieldsfile.tellg();											// Saves the current position of the file marker in case the next entry has a different field
			getline(fieldsfile, s1);													// Copies the next entry's field name to s1 so it can be compared in the next while loop iteration
		}
		if (s1 == ""){ break; }															// Quits if there's a blank line to avoid infinite looping if it happens at eof
		fieldsfile.seekg(displacement2, fieldsfile.beg);								// Breaking from while loop means a different country has been read. Returns one line of the country file
		catalog << endl;																// Writes a newline on the final catalog file to start processing a new country
	}

	fieldsfile.close();
	namesfile.close();
	catalog.close();

}

// LOOKUP FUNCTIONS

void getName(){
	fstream namesfile;
	fstream mainfile;
	string word;
	string s1;
	string name;
	int displacement;

	system("cls");
	cout << "CONSULTA POR PALAVRA DO TITULO" << endl; 
	cout << "Digite a palavra a ser pesquisada: " << endl;
	cin >> word;
	cout << endl;

	namesfile.open("namesCatalog.bin");
	mainfile.open("Artigos.csv");

	while (!namesfile.eof()){
		getline(namesfile, name);
		if (name == "") { break; }
		for (char c : name){
			if (c == ' '){
				if (word == s1){
					getline(namesfile, s1);
					{istringstream convert(s1);													// Creates stream object used to convert string to int
					convert >> displacement;													// Puts conversion in the s1 variable
					}																			// Ends scope to delete istringstream object
					mainfile.seekg(displacement, mainfile.beg);
					getline(mainfile, name);
					cout << name << endl;
					cout << endl;
					break;
				}
				else { s1 = ""; }
			}
			else s1 += c;
		}

	}

	namesfile.close();
	mainfile.close();

	cout << "Busca concluida. Entre qualquer tecla para retornar." << endl;
	cin >> word;
}

struct Author{
	string name;
	int count;
};

bool sortByCount(const Author &lhs, const Author &rhs) { return lhs.count < rhs.count; }

void getFieldCount(){
	fstream fieldsfile;
	fstream authorsfile;
	int displacement;
	string s1;
	string s2;
	vector<int> fieldDisps;
	vector<Author> allAuthors;
	Author currentAuthor;

	system("cls");
	cout << "CONSULTA POR AREA DO ARTIGO" << endl << endl << "Digite a area a ser pesquisada: " << endl;
	while (s2 == ""){ getline(cin, s2); }
	cout << endl;

	fieldsfile.open("fieldsCatalog2.bin");												// Opens Fields file

	while (!fieldsfile.eof()){															// Finds appropriate field entry
		getline(fieldsfile, s1);
		s1 = ptgSucks(s1);
		if (s1 == s2){ getline(fieldsfile, s1); break; }
		else getline(fieldsfile, s1);													// Gets address line but disregards it
	}

	if (fieldsfile.eof()){
		cout << "Busca concluida. Entre qualquer tecla para retornar." << endl;
		cin >> s1;
		return;
	}

	fieldsfile.close();																	// Closes Fields file
	s2 = "";																			// Resets s2 as it will now store a displacement in string form
	for (char c : s1){
		if (c == ';') {																	// If semicolon separator has been reached:
			{ istringstream convert(s2);												// Converts string to int
			convert >> displacement;													
			}																			
			fieldDisps.push_back(displacement);											// Pushes to vector of all addresses of articles from requested area
			s2 = ""; }																	// Resets auxiliary string for next iteration
		else s2 += c;																	// Else add char to auxiliary string and repeat for next char
	}

	authorsfile.open("authorsCatalog2.bin");											// Opens Authors file

	while (!authorsfile.eof()){
		getline(authorsfile, currentAuthor.name);										// Places author name on currentAuthor
		if (currentAuthor.name == "") { break; }										// Quits in case blank line is reached
		currentAuthor.count = 0;														// Resets counter
		getline(authorsfile, s1);														// Places addresses line on string for processing
		s2 = "";																		// Resets auxiliary string 

		for (char c : s1){																// This loop computes the number of articles associated with an author belonging to a given area
			if (c == ';') {																// If semicolon separator has been reached:
				{ istringstream convert(s2);											// Converts string to int
				convert >> displacement;
				}
				for (int i : fieldDisps){												// Then, compares said int to every address stored in the fieldDisps vector
					if (i == displacement){ currentAuthor.count++; break; }				// If one of them matches, increase counter for that author,
				}																		// then quits comparing to fieldDisps vector (as each entry is unique)
				s2 = "";																// Resets auxiliary string for next iteration
			}																			
			else s2 += c;																// Else add char to auxiliary string and repeat for next char
		}

		allAuthors.push_back(currentAuthor);											// Places an author struct on the vector after counting is done
	}

	authorsfile.close();
	sort(allAuthors.rbegin(), allAuthors.rend(), sortByCount);

	for (Author a : allAuthors){
		if (a.count != 0){
			cout << a.name << endl << a.count << endl;
		}
	}

	cout << "Busca concluida. Entre qualquer tecla para retornar." << endl;
	cin >> s1;

}

void getAuthors(){
	fstream authorsfile;
	fstream mainfile;
	int displacement;
	string s1;
	string s2;
	string firstauthor;
	vector<int> current;
	vector<int> accumulated;
	vector<int> newResult;
	vector<string> authors;

	system("cls");
	cout << "CONSULTA POR CONJUNTO DE AUTORES" << endl << endl << "Entre pelo menos dois autores, um autor por vez. Entre um ponto para terminar" << endl << endl;

	while (firstauthor == ""){ getline(cin, firstauthor); }
	while (true){
		getline(cin, s1);
		if (s1 == "."){ break; }
		authors.push_back(s1);
	}

	cout << endl << endl;

	authorsfile.open("authorsCatalog2.bin");

	while (!authorsfile.eof()){															// Gets addresses string for the first author
		getline(authorsfile, s1);
		if (s1 == firstauthor){ getline(authorsfile, s1); break; }
		else getline(authorsfile, s1);													// Reads addresses line from rejected author name just to move the file marker
	}

	for (char c : s1){																	// Converts it into a vector of ints
		if (c == ';') {																	// If semicolon separator has been reached:
			{ istringstream convert(s2);												// Converts string to int
			convert >> displacement;
			}
			accumulated.push_back(displacement);										// Pushes to vector of all addresses of articles from requested area
			s2 = "";																	// Resets auxiliary string for next iteration
		}																				
		else s2 += c;																	// Else add char to auxiliary string and repeat for next char
	}

	for (string s : authors){															// Now processes other authors
		authorsfile.seekg(0, authorsfile.beg);											// Repositions file marker at beginning
		while (!authorsfile.eof()){
			getline(authorsfile, s1);
			if (s1 == s){ getline(authorsfile, s1); break; }
			else getline(authorsfile, s1);												
		}

		current.clear();																// Resets current author's addresses vector

		for (char c : s1){																// Converts it into a vector of ints
			if (c == ';') {																// If semicolon separator has been reached:
				{ istringstream convert(s2);											// Converts string to int
				convert >> displacement;
				}
				current.push_back(displacement);										// Pushes to vector of all addresses of articles from requested area
				s2 = "";																// Resets auxiliary string for next iteration
			}																			
			else s2 += c;																// Else add char to auxiliary string and repeat for next char
		}

		for (int i : accumulated){
			for (int j : current){
				if (i == j){ newResult.push_back(j); break; }
			}
		}

		accumulated = newResult;
		newResult.clear();																// Resets new result vector
	}

	authorsfile.close();
	mainfile.open("Artigos.csv");

	for (int i : accumulated){
		mainfile.seekg(i, mainfile.beg);
		getline(mainfile, s1);
		cout << s1 << endl << endl;
	}

	mainfile.close();

	cout << "Busca concluida. Entre qualquer tecla para retornar." << endl;
	cin >> s1;

}

void getAuthor(){
	fstream authorsfile;
	fstream mainfile;
	int displacement;
	string s1;
	string s2;
	vector<int> displacements;

	system("cls");
	cout << "CONSULTA AUTOR" << endl << endl << "Entre o nome do autor" << endl << endl;
	while (s1 == ""){ getline(cin, s1); }
	cout << endl << endl;
	authorsfile.open("authorsCatalog2.bin");

	while (!authorsfile.eof()){															// Gets addresses string for the first author
		getline(authorsfile, s2);
		if (s2 == s1){ getline(authorsfile, s2); break; }
		else getline(authorsfile, s2);													// Reads addresses line from rejected author name just to move the file marker
	}
	
	if (authorsfile.eof()){
		cout << "Busca concluida. Entre qualquer tecla para retornar." << endl;
		cin >> s1;
		return;
	}
	authorsfile.close();
	s1 = "";																			// Resets s1 as it will now store a displacement in string form

	for (char c : s2){																	// Converts addresses line into a vector of ints
		if (c == ';') {																	// If semicolon separator has been reached:
			{ istringstream convert(s1);												// Converts string to int
			convert >> displacement;
			}
			displacements.push_back(displacement);										// Pushes to vector of all addresses of articles from requested area
			s1 = "";																	// Resets auxiliary string for next iteration
		}
		else s1 += c;																	// Else add char to auxiliary string and repeat for next char
	}

	mainfile.open("Artigos.csv");

	for (int i : displacements){
		mainfile.seekg(i, mainfile.beg);
		getline(mainfile, s1);
		cout << s1 << endl << endl;
	}

	mainfile.close();

	cout << "Busca concluida. Entre qualquer tecla para retornar." << endl;
	cin >> s1;
}

void getCountry(){
	fstream countriesfile;
	fstream mainfile;
	int displacement;
	string s1;
	string s2;
	vector<int> displacements;

	system("cls");
	cout << "CONSULTA PAIS" << endl << endl << "Entre o nome do pais" << endl << endl;
	while (s1 == ""){ getline(cin, s1); }
	cout << endl << endl;
	countriesfile.open("countriesCatalog2.bin");

	while (!countriesfile.eof()){														// Gets addresses string for the first country
		getline(countriesfile, s2);
		if (s2 == s1){ getline(countriesfile, s2); break; }
		else getline(countriesfile, s2);												// Reads addresses line from rejected author name just to move the file marker
	}

	if (countriesfile.eof()){
		cout << "Busca concluida. Entre qualquer tecla para retornar." << endl;
		cin >> s1;
		return;
	}
	countriesfile.close();
	s1 = "";																			// Resets s1 as it will now store a displacement in string form

	for (char c : s2){																	// Converts addresses line into a vector of ints
		if (c == ';') {																	// If semicolon separator has been reached:
			{ istringstream convert(s1);												// Converts string to int
			convert >> displacement;
			}
			displacements.push_back(displacement);										// Pushes to vector of all addresses of articles from requested area
			s1 = "";																	// Resets auxiliary string for next iteration
		}
		else s1 += c;																	// Else add char to auxiliary string and repeat for next char
	}

	mainfile.open("Artigos.csv");

	for (int i : displacements){
		mainfile.seekg(i, mainfile.beg);
		getline(mainfile, s1);
		cout << s1 << endl << endl;
	}

	mainfile.close();

	cout << "Busca concluida. Entre qualquer tecla para retornar." << endl;
	cin >> s1;
}

int selector(int sair){
	string input;

	system("cls");
	cout << "Entre um numero para fazer sua consulta correspondente. Entre s para sair." << endl << endl
		<< "1. Consulta por palavra do nome do artigo." << endl
		<< "2. Consulta por autor." << endl
		<< "3. Consulta por conjunto de autores" << endl
		<< "4. Listagem de frequencia por area" << endl
		<< "5. Consulta por pais de origem" << endl << endl;

	while (true){
		cin >> input;
		if (input == "s"){ return 1; }
		else if (input == "1") { getName(); return 0; }
		else if (input == "2"){ getAuthor(); return 0; }
		else if (input == "3"){ getAuthors(); return 0; }
		else if (input == "4"){ getFieldCount(); return 0; }
		else if (input == "5"){ getCountry(); return 0; }
		else cout << "Comando nao reconhecido." << endl;
		input.clear();
	}

}

int main(){
	fstream file;
	char fim;
	string s1;
	int sair = 0;

	catalogNames();																		// Creates name-keyed index
	catalogAuthors();																	// Creates author-keyed index
	catalogAuthors2();																	// Creates non-redundant author-keyed index
	catalogCountries();																	// Creates country-keyed index
	catalogCountries2();																// Creates non-redundant country-keyed index
	catalogFields();																	// Creates field-keyed index
	catalogFields2();																	// Creates non-redundant field-keyed index

	file.open("Artigos.csv");
	if (!file.is_open()){ cout << "Arquivo nao encontrado!"; cin >> fim; file.close(); return -1; }
	file.close();

	while (true){
		if (selector(sair) == 1){ return 0; }
	}
	
}
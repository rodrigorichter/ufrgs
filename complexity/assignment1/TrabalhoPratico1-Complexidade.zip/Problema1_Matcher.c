#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int *ComputaPrefixo(char PREFIXO[],int TAMANHO)
{
    int m = TAMANHO;
    int *FuncaoPrefixo = (int *)calloc(m,sizeof(int));
    int k,q;

    k = 0;
    FuncaoPrefixo[0] = 0;
    for(q=1; q<TAMANHO; q++)
    {
        while(k>0 && ((PREFIXO[k])!= (PREFIXO[q])))
        {
            k = FuncaoPrefixo[k-1];
        }
        if(PREFIXO[k]==PREFIXO[q])
            k++;
        FuncaoPrefixo[q]=k;
    }
    return FuncaoPrefixo;
}

int KMP_Matcher(char TEXTO[],char PADRAO[])
{
    int n = strlen(TEXTO);
    int m = strlen(PADRAO);
    int *FuncaoPrefixo = ComputaPrefixo(PADRAO,m);
    int num_caracteres,IndiceTexto,ACHOU = 0;

    num_caracteres = 0;
    for(IndiceTexto=0; IndiceTexto<n; IndiceTexto++)
    {
        while(num_caracteres>0 &&(PADRAO[num_caracteres]!=TEXTO[IndiceTexto]))
            num_caracteres = FuncaoPrefixo[num_caracteres-1];
        if(PADRAO[num_caracteres]==TEXTO[IndiceTexto])
            num_caracteres++;
        if(num_caracteres == m)
        {
            ACHOU = 1;
            num_caracteres = FuncaoPrefixo[num_caracteres-1];
        }
    }
    free(FuncaoPrefixo);
    return ACHOU;
}

int main()
{
    char n[] = "10";
    char Texto[] = "1234567890";
    char Padrao[] = "0045671232";
    int TAMANHO_STRING = atoi(n);
    char SUB_STRING[TAMANHO_STRING];
    char Chave[TAMANHO_STRING];
    int TAMANHO_SUBSTRING;
    int TAM_PADRAO_ATUAL = 0;
    int i,j,k;

    TAMANHO_SUBSTRING = 3;
    while(TAMANHO_SUBSTRING<=TAMANHO_STRING)
    {
        i=0;
        while(i+TAMANHO_SUBSTRING<=TAMANHO_STRING)
        {
            for(k=0,j=1; j<=TAMANHO_SUBSTRING; i++,j++,k++)
            {
                SUB_STRING[k] = Padrao[i];
            }
            SUB_STRING[k] = '\0';
            if((TAMANHO_SUBSTRING>TAM_PADRAO_ATUAL)&&(KMP_Matcher(Texto,SUB_STRING)))
            {
                TAM_PADRAO_ATUAL = TAMANHO_SUBSTRING;
                strcpy(Chave,SUB_STRING);
            }
            i = (i-TAMANHO_SUBSTRING)+1;
        }
        TAMANHO_SUBSTRING++;
    }
    printf("String 1: %s\n",Texto);
    printf("String 2: %s\n",Padrao);
    printf("Chave Encontrada: %s\n",Chave);
    return 0;
}


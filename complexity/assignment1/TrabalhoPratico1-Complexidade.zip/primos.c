#include <stdio.h>
#include <stdlib.h>

int FATORACAO(long long int n)
{
    long int numero = n;
    int divisor = 1;
    long int resto;
    int i=2;

    while(numero!=1)
    {
        resto = numero%i;
        if(resto==0)
        {
            divisor = i;
            numero/=i;
        }
        else
            i++;
    }
    return divisor;
}


int main()
{
    long int n;
    int MAIOR_DIVISOR;

    n=1994799;
    MAIOR_DIVISOR = FATORACAO(n);
    printf("Maior divisor de %ld: %d\n",n,MAIOR_DIVISOR);
    return 0;
}

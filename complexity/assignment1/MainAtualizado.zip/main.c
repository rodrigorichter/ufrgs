#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "libhack.h"


int *ComputaPrefixo(char PREFIXO[],int TAMANHO);
int KMP_Matcher(char TEXTO[],char PADRAO[]);
char *EncontraChave(char TEXTO1[],char TEXTO2[],int TAMANHO);
int Fatoracao(long int n);

int main(int argc, char** argv) {
	if (argc > 1) {
	  setMapSeed(atoi(argv[1]));
	}

	setHackerName("Cypherpunks");
	char** map = readMap();
	printMap();
	hackerSpeak("Mission start");
	printf("Hacker Info:  Position = (%d,%d)  Speed = %1.0f\n",getHackerRow(),getHackerCol(),getHackerSpeed());

	int mapCols = getMapCols();
	int mapRows = getMapRows();
	Problem2 doorProblem;
	Problem1 computerProblem;
	Problem2 sensorProblem;
	char computersAnswers[100][1000];
	int amountOfComputers = 0;
	//char key[1000]; string que é o resultado das tuas funçoes de resolver os problemas
	printf("Map Size: (%d,%d)\n",mapRows,mapCols);

	int doorCol = -1;
	int doorRow = -1;

	for (int i = 0; i < mapRows; i++) {
		for (int j = 0; j < mapCols; j++) {
			if (map[i][j] == DOOR) {
				doorCol = j;
				doorRow = i;
				break;
			}
		}
	}

	printf("The exit door is located at (%d,%d)\n",doorRow,doorCol);

	moveHackerTo(doorRow,doorCol);

	doorProblem = inspectDoor(doorRow,doorCol);

	//loop que percore do inicio ao fim o mapa, e vai andando e hackeando
	for (int i = 0; i < mapRows; i++) {
		for (int j = 0; j < mapCols; j++) {

			if (map[i][j] == COMPUTER) {
				moveHackerTo(i,j);
				computerProblem = inspectComputer(i,j);
				int Tamanho = computerProblem.n;
                char *key = EncontraChave(computerProblem.a,computerProblem.b,Tamanho);
				if(hackComputer(i,j,key))
                {
                    strcpy(computersAnswers[amountOfComputers],key);
                }
				amountOfComputers++;
			}
			if (map[i][j] == SENSOR) {
				moveHackerTo(i,j);
				sensorProblem = inspectSensor(i,j);
				long int n = atol(sensorProblem.a);
				char key[n];
				int Maior_Divisor = Fatoracao(n);
				itoa(Maior_Divisor,key,10);
				hackSensor(i,j,key);
			}
		}
	}

	//char possibleAnswer[1000]
/*	for (int i=0;i<amountOfComputers;i++) {
		for (int j=0;j<amountOfComputers;j++) {
			//possibleAnswer = computersAnswers[i] * computersAnswers[j] // temos que fazer um jeito de multiplicar esses numeros. o problema'e que eles sao strings ne
			if (strcmp(possibleAnswer,doorProblem.a)) {
				hackDoor(doorRow,doorCol,possibleAnswer);
			}
		}
	}*/
	return 0;
}

int *ComputaPrefixo(char PREFIXO[],int TAMANHO)
{
    int m = TAMANHO;
    int *FuncaoPrefixo = (int *)calloc(m,sizeof(int));
    int k,q;

    k = 0;
    FuncaoPrefixo[0] = 0;
    for(q=1; q<TAMANHO; q++)
    {
        while(k>0 && ((PREFIXO[k])!= (PREFIXO[q])))
        {
            k = FuncaoPrefixo[k-1];
        }
        if(PREFIXO[k]==PREFIXO[q])
            k++;
        FuncaoPrefixo[q]=k;
    }
    return FuncaoPrefixo;
}

int KMP_Matcher(char TEXTO[],char PADRAO[])
{
    int n = strlen(TEXTO);
    int m = strlen(PADRAO);
    int *FuncaoPrefixo = ComputaPrefixo(PADRAO,m);
    int num_caracteres,IndiceTexto,ACHOU = 0;

    num_caracteres = 0;
    for(IndiceTexto=0; IndiceTexto<n; IndiceTexto++)
    {
        while(num_caracteres>0 &&(PADRAO[num_caracteres]!=TEXTO[IndiceTexto]))
            num_caracteres = FuncaoPrefixo[num_caracteres-1];
        if(PADRAO[num_caracteres]==TEXTO[IndiceTexto])
            num_caracteres++;
        if(num_caracteres == m)
        {
            ACHOU = 1;
            num_caracteres = FuncaoPrefixo[num_caracteres-1];
        }
    }
    free(FuncaoPrefixo);
    return ACHOU;
}

char *EncontraChave(char TEXTO1[],char TEXTO2[],int TAMANHO)
{
    int TAMANHO_STRING = TAMANHO;
    char SUB_STRING[TAMANHO_STRING];
    char *Chave = (char *)calloc(TAMANHO,sizeof(char));
    int TAMANHO_SUBSTRING;
    int TAM_PADRAO_ATUAL = 0;
    int i,j,k;

    TAMANHO_SUBSTRING = 3;
    while(TAMANHO_SUBSTRING<=TAMANHO_STRING)
    {
        i=0;
        while(i+TAMANHO_SUBSTRING<=TAMANHO_STRING)
        {
            for(k=0,j=1; j<=TAMANHO_SUBSTRING; i++,j++,k++)
            {
                SUB_STRING[k] = TEXTO2[i];
            }
            SUB_STRING[k] = '\0';
            if((TAMANHO_SUBSTRING>TAM_PADRAO_ATUAL)&&(KMP_Matcher(TEXTO1,SUB_STRING)))
            {
                TAM_PADRAO_ATUAL = TAMANHO_SUBSTRING;
                strcpy(Chave,SUB_STRING);
            }
            i = (i-TAMANHO_SUBSTRING)+1;
        }
        TAMANHO_SUBSTRING++;
    }
    return Chave;
}

int Fatoracao(long int n)
{
    long int numero = n;
    int divisor = 1;
    long int resto;
    int i=2;

    while(numero!=1)
    {
        resto = numero%i;
        if(resto==0)
        {
            divisor = i;
            numero/=i;
        }
        else
            i++;
    }
    return divisor;
}
